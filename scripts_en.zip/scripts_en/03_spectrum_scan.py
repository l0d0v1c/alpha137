#!/usr/bin/env python3
"""
03 - Scan of vector-like spectra: which matter contents make the three gauge couplings
     simultaneously strong (0 <= alpha_i^-1(Lambda) <= 1) at a common scale Lambda?
     One loop, a single common mass M >= 1 TeV. Control: decoy worlds.

Usage: python3 03_spectrum_scan.py [number_of_decoys]   (default 20; 80 were used for the paper,
       allow several minutes per configuration)
"""
import numpy as np, itertools, math, sys
tp = 2*math.pi; MZ = 91.1876
AINV, S2W, AS = 127.951, 0.23122, 0.1180
A = np.array([AINV*(1-S2W), AINV*S2W, 1/AS])          # 1/alpha_Y, 1/alpha_2, 1/alpha_3 at M_Z
bSM = np.array([41/6, -19/6, -7.0]); bMSSM = np.array([11.0, 1.0, -3.0])   # convention Q = T3 + Y
# (db_Y, db_2, db_3) per vector-like Dirac fermion; T and G: real fermions
FIELDS = {"E":(4/3,0,0), "L":(2/3,2/3,0), "D":(4/9,0,2/3), "U":(16/9,0,2/3),
          "Q":(2/9,2,4/3), "T":(0,4/3,0), "G":(0,0,2)}
names = list(FIELDS); C = np.array(list(FIELDS.values()))
S = np.array(list(itertools.product(*[range(7)]*5, range(3), range(3))))
comp = S.sum(1)
su5 = (S[:,1]==S[:,2]) & (S[:,0]==S[:,3]) & (S[:,0]==S[:,4]) & (S[:,5]==0) & (S[:,6]==0)

def feasible(A, susy, xlo, xhi, nx=40, Mmin=1000.):
    """For each spectrum: is there (Lambda, M) such that alpha_i^-1(Lambda) lies in [0,1] for all i?
       x = ln(Lambda/MZ), y = ln(Lambda/M). At fixed x, each coupling imposes an interval in y."""
    db = S@C*(1.5 if susy else 1.0)                    # supermultiplets: x 3/2
    if susy: db = db + (bMSSM - bSM)                   # superpartners at the same scale M
    x = np.linspace(xlo, xhi, nx); ymax = x - math.log(Mmin/MZ)
    lo = np.zeros((len(S), nx)); hi = np.broadcast_to(ymax, (len(S), nx)).copy()
    ok = np.ones((len(S), nx), bool)
    for i in range(3):
        up = tp*A[i] - bSM[i]*x; dn = up - tp          # db_i * y must fall in [dn, up]
        d = db[:, i][:, None]
        with np.errstate(divide='ignore', invalid='ignore'):
            l = np.where(d > 0, dn/d, -np.inf); h = np.where(d > 0, up/d, np.inf)
        ok &= np.where(d > 0, True, (dn <= 0) & (up >= 0))
        lo = np.maximum(lo, l); hi = np.minimum(hi, h)
    f = ok & (lo <= hi); any_ = f.any(1)
    ix = np.where(any_, (f*np.arange(nx)).sum(1)//np.maximum(f.sum(1), 1), 0)
    r = np.arange(len(S))
    return any_, x[ix], (lo[r, ix] + hi[r, ix])/2

if __name__ == "__main__":
    ndec = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    X = lambda lam: math.log(lam/MZ)
    windows = {"Lambda free 1e10 - 1.22e19 GeV": (X(1e10), X(1.22e19), 60),
               "Planck window 2.4e18 - 1.22e19 GeV": (X(2.435e18), X(1.22e19), 30)}
    rng = np.random.default_rng(11)
    print(len(S), "spectra; couplings at M_Z:", np.round(A, 3))
    for susy in (False, True):
        for wn, (a, b, nx) in windows.items():
            ok, xb, yb = feasible(A, susy, a, b, nx)
            print(f"\n### base {'MSSM (superpartners at M)' if susy else 'Standard Model'} | {wn}")
            print(f"  compatible spectra: {ok.sum()} ({100*ok.mean():.2f} %); minimal complexity: {comp[ok].min()}")
            for w in (1.25, 1.5, 2.0):
                dec = A*np.exp(rng.uniform(-math.log(w), math.log(w), (ndec, 3)))
                nd = np.array([feasible(d, susy, a, b, nx)[0].sum() for d in dec])
                print(f"  decoys x{w:<4}: median {np.median(nd):6.0f} | P(decoy >= real) = {np.mean(nd >= ok.sum()):.3f}")
            for j in np.where(ok)[0][np.argsort(comp[ok])][:5]:
                lam = MZ*math.exp(xb[j]); M = lam*math.exp(-yb[j])
                print("    ", {n: int(v) for n, v in zip(names, S[j]) if v}, f"Lambda ~ {lam:.1e}  M ~ {M:.1e} GeV")
            print("   complete SU(5) multiplets (n5, n10):", [(int(S[j][1]), int(S[j][0])) for j in np.where(ok & su5)[0]])
    # test of the interpretation: the excess in the Planck window comes from the near-equality of the required db
    print("\n### 'democracy' test (SM base, Planck window): required R_i = db_i * y")
    a, b, nx = windows["Planck window 2.4e18 - 1.22e19 GeV"]; x0 = (a+b)/2
    print("  real world: R =", np.round(tp*A - bSM*x0, 1))
    for R in [(330,330,330), (420,330,250), (250,330,420), (500,330,160), (160,330,500)]:
        Ad = (np.array(R) + bSM*x0)/tp
        print(f"  R = {R} -> {feasible(Ad, False, a, b, nx)[0].sum()} spectra")
