#!/usr/bin/env python3
"""
09 - Comparison of architectures with a penalty for continuous parameters (Bayesian evidence),
     sensitivity of k_Y to an intermediate supersymmetry scale, and a cross-check with the Higgs.

 A. Evidence  Z = Int d(theta) prior(theta) L(theta), Laplace approximation.
    Observables: (1/alpha_Y, 1/alpha_2, 1/alpha_3) at M_t. Gaussian likelihood, sigma = theoretical
    error per coupling (unknown thresholds at M_U). Flat priors: ln M on [1 TeV, M_Pl],
    1/alpha_U on [0, 100], k_Y (when free) on [1, 2]. The Occam factor automatically penalises
    each continuous parameter; a discrete choice among n options costs a factor 1/n.
 B. Required k_Y if supersymmetry appears at an intermediate scale M_S (SM below,
    MSSM above), two loops.
 C. Higgs quartic coupling lambda(mu) (approximate NLO): sign at M_U, and the Higgs mass
    that lambda(M_U) >= 0 would require (supersymmetry broken at M_U).
"""
import numpy as np, math
from fractions import Fraction as Fr
MT, MPL = 173.34, 1.22e19; K = 1/(16*math.pi**2); ainv = lambda g: 4*math.pi/g**2
g3_0 = 1.1666 + 0.00314*(0.1180-0.1184)/0.0007
Y0 = np.array([math.sqrt(5/3)*0.35830, 0.64779, g3_0, 0.93690])          # g1 (SU(5) norm.), g2, g3, y_t at M_t
OBS = np.array([(5/3)*ainv(Y0[0]), ainv(Y0[1]), ainv(Y0[2])])

MODELS = {   # coefficients in SU(5) normalisation for g1
 "SM":   (np.array([41/10, -19/6, -7.0]), np.array([[199/50,27/10,44/5],[9/10,35/6,12.],[11/10,9/2,-26.]]),
          np.array([17/10,3/2,2.]), (4.5, 17/20, 9/4, 8.)),
 "MSSM": (np.array([33/5, 1., -3.]),      np.array([[199/25,27/5,88/5],[9/5,25.,24.],[11/5,9.,14.]]),
          np.array([26/5,6.,4.]),  (6.0, 13/15, 3., 16/3)),
}
def beta(y, model, loops=2):
    b, B, Ct, c = MODELS[model]; g, yt = y[:3], y[3]
    dg = K*b*g**3 + (K*K*g**3*(B@(g**2) - Ct*yt**2) if loops == 2 else 0)
    return np.append(dg, K*yt*(c[0]*yt**2 - c[1]*g[0]**2 - c[2]*g[1]**2 - c[3]*g[2]**2))
def run(y, t0, t1, model, n=600):
    y, h = np.array(y, float), (t1-t0)/n
    for _ in range(n):
        k1 = beta(y, model); k2 = beta(y+h/2*k1, model); k3 = beta(y+h/2*k2, model); k4 = beta(y+h*k3, model)
        y = y + h/6*(k1+2*k2+2*k3+k4)
    return y
SB = math.sin(math.atan(10.))                                             # tan(beta) = 10
def up(tS, tU):      # from M_t to M_U, SM then MSSM above M_S (tS=None: SM only)
    if tS is None or tS >= tU: return run(Y0, math.log(MT), tU, "SM")
    y = run(Y0, math.log(MT), tS, "SM"); y[3] /= SB
    return run(y, tS, tU, "MSSM")
def down(tU, aUinv, kY, tS, ytU):
    gU = math.sqrt(4*math.pi/aUinv); y = [math.sqrt(5/3)*gU/math.sqrt(kY), gU, gU, ytU]
    if tS is None or tS >= tU: y = run(y, tU, math.log(MT), "SM")
    else:
        y = run(y, tU, tS, "MSSM"); y[3] *= SB; y = run(y, tS, math.log(MT), "SM")
    return np.array([(5/3)*ainv(y[0]), ainv(y[1]), ainv(y[2])])

def crossing(tS):
    """M_U where alpha_2 = alpha_3, 1/alpha_U, required k_Y."""
    lo, hi = math.log(1e13), math.log(MPL)
    for _ in range(40):
        mid = (lo+hi)/2; y = up(tS, mid)
        if ainv(y[1]) > ainv(y[2]): lo = mid
        else: hi = mid
    y = up(tS, mid); return mid, ainv(y[1]), (5/3)*ainv(y[0])/ainv(y[1]), y[3]

def evidence(kind, kY=None, tS=None, sigma=0.5):
    tU, aU, kreq, ytU = crossing(tS)
    if kind == "unif":            # parameters (ln M_U, 1/alpha_U); k_Y fixed
        th = np.array([tU, aU]); f = lambda p: down(p[0], p[1], kY, tS, ytU); vol = math.log(MPL/1e3)*100
    elif kind == "kfree":         # + continuous k_Y
        th = np.array([tU, aU, kreq]); f = lambda p: down(p[0], p[1], p[2], tS, ytU); vol = math.log(MPL/1e3)*100*1.0
    elif kind == "unif+MS":       # + continuous ln M_S
        th = np.array([tU, aU, tS]); f = lambda p: down(p[0], p[1], kY, p[2], ytU); vol = math.log(MPL/1e3)**2*100
    elif kind == "het":           # a single parameter g_s; M_s = 5.27e17 g_s
        th = np.array([0.508]); f = lambda p: down(math.log(5.27e17*p[0]), 4*math.pi/p[0]**2, kY, None, ytU); vol = 1.0
    eps = np.array([1e-3]*len(th))
    for _ in range(6):            # Gauss-Newton
        r = f(th) - OBS
        J = np.array([(f(th + e*np.eye(len(th))[j]) - OBS - r)/e for j, e in enumerate(eps)]).T
        if J.shape[0] == J.shape[1]: th = th - np.linalg.solve(J, r)
        else: th = th - np.linalg.lstsq(J, r, rcond=None)[0]
    r = f(th) - OBS; chi2 = float(r@r)/sigma**2; n, m = 3, len(th)
    lnZ = -0.5*chi2 + 0.5*(m-n)*math.log(2*math.pi*sigma**2) - 0.5*math.log(abs(np.linalg.det(J.T@J))) - math.log(vol)
    return lnZ, chi2, th, r

if __name__ == "__main__":
    print("== A. Evidence (Laplace approximation), two loops ==")
    for sigma in (0.5, 1.0):
        print(f"  theoretical error sigma = {sigma} unit of 1/alpha per coupling")
        rows = [("SM, k_Y = 5/3", "unif", 5/3, None), ("SM, k_Y = 4/3", "unif", 4/3, None),
                ("SM, k_Y = 13/10", "unif", 1.3, None), ("SM, k_Y = 32/25", "unif", 1.28, None),
                ("SM, k_Y free (continuous)", "kfree", None, None),
                ("MSSM at 3 TeV, k_Y = 5/3", "unif", 5/3, math.log(3e3)),
                ("MSSM, M_S free, k_Y = 5/3", "unif+MS", 5/3, math.log(3e3)),
                ("heterotic, k_Y = 4/3 (1 param.)", "het", 4/3, None)]
        res = [(lab,)+evidence(kind, kY, tS, sigma) for lab, kind, kY, tS in rows]
        ref = max(x[1] for x in res)
        for lab, lnZ, chi2, th, r in res:
            print(f"    {lab:36s} chi2_min = {chi2:8.2f}   ln Z = {lnZ:8.2f}   Bayes factor / best = {math.exp(lnZ-ref):.2e}")
    print("\n== B. Required k_Y versus the supersymmetry scale M_S (two loops) ==")
    for MS in (1e3, 1e4, 1e6, 1e8, 1e10, 1e11, 1e12, 1e14, None):
        tU, aU, kreq, _ = crossing(None if MS is None else math.log(MS))
        print(f"    M_S = {('%.0e GeV' % MS) if MS else 'none (pure SM)':>16s} : M_U = {math.exp(tU):.2e}  1/alpha_U = {aU:5.2f}  required k_Y = {kreq:.3f}")

    print("\n== C. Higgs quartic (approximate NLO: lambda and y_t with leading two-loop terms) ==")
    def lam_run(lam0, mt_shift=0.0):
        y = np.append(Y0.copy(), lam0); y[3] += 0.00556*mt_shift
        t, tU = math.log(MT), math.log(2.9e16); n = 4000; h = (tU-t)/n; tcross = None
        def f(y):
            g1, g2, g3, yt, l = y; gp2 = 0.6*g1*g1
            dg = beta(y[:4], "SM")
            dyt2 = K*K*yt*(-12*yt**4 + 36*g3*g3*yt*yt - 108*g3**4 + 6*l*l - 12*l*yt*yt)
            dl = K*(24*l*l + 12*l*yt*yt - 6*yt**4 - 3*l*(3*g2*g2+gp2) + 0.375*(2*g2**4 + (g2*g2+gp2)**2)) \
               + K*K*(-312*l**3 - 144*l*l*yt*yt - 3*l*yt**4 + 30*yt**6 + 80*l*g3*g3*yt*yt - 32*g3*g3*yt**4)
            dg[3] += dyt2; return np.append(dg, dl)
        for i in range(n):
            k1 = f(y); k2 = f(y+h/2*k1); k3 = f(y+h/2*k2); k4 = f(y+h*k3); yn = y + h/6*(k1+2*k2+2*k3+k4)
            if tcross is None and y[4] > 0 >= yn[4]: tcross = t + i*h
            y = yn
        return y[4], tcross
    for dmt in (0.0, -0.64, -2.0):
        lU, tc = lam_run(0.12604, dmt)
        print(f"    M_t = {173.34+dmt:6.2f} GeV : lambda(M_U) = {lU:+.4f} ; lambda = 0 at mu = " + (f"{math.exp(tc):.1e} GeV" if tc else "never"))
    lo, hi = 0.12, 0.16
    for _ in range(30):
        mid = (lo+hi)/2
        if lam_run(mid)[0] < 0: lo = mid
        else: hi = mid
    print(f"    lambda(M_U) >= 0 requires lambda(M_t) >= {mid:.4f}, i.e. M_h >~ {125.15 + (mid-0.12604)*125.15/(2*0.12604):.1f} GeV  (measured: 125.2; NNLO literature: ~129-130)")
    g2U = 4*math.pi/46.18
    print(f"    supersymmetric window at M_U: 0 <= lambda <= (g2^2+gY^2)/8 = {(g2U + g2U*3/4)/8:.4f}")

    # == D. Evidence of the 'rigid strong coupling' family (script 03), one loop ==
    # Likelihood: c_i = alpha_i^-1(Lambda) uniform in [0,1] (density 1 per unit of 1/alpha),
    # flat priors in ln(Lambda) and ln(M) on [1 TeV, M_Pl], uniform prior over the 151,263 spectra.
    import itertools
    tp = 2*math.pi; MZ = 91.1876
    A = np.array([127.951*(1-0.23122), 127.951*0.23122, 1/0.1180]); bSM = np.array([41/6, -19/6, -7.0])
    C = np.array([(4/3,0,0),(2/3,2/3,0),(4/9,0,2/3),(16/9,0,2/3),(2/9,2,4/3),(0,4/3,0),(0,0,2)])
    S = np.array(list(itertools.product(*[range(7)]*5, range(3), range(3)))); db = S@C
    x = np.linspace(math.log(1e10/MZ), math.log(MPL/MZ), 200); dx = x[1]-x[0]; ymax = x - math.log(1e3/MZ)
    lo = np.zeros((len(S), len(x))); hi = np.broadcast_to(ymax, lo.shape).copy(); ok = np.ones(lo.shape, bool)
    for i in range(3):
        upb = tp*A[i] - bSM[i]*x; dn = upb - tp; d = db[:, i][:, None]
        with np.errstate(divide='ignore', invalid='ignore'):
            lo = np.maximum(lo, np.where(d > 0, dn/d, -np.inf)); hi = np.minimum(hi, np.where(d > 0, upb/d, np.inf))
        ok &= np.where(d > 0, True, (dn <= 0) & (upb >= 0))
    area = (np.where(ok, np.clip(hi-lo, 0, None), 0).sum(1)*dx)
    V = math.log(MPL/1e3)**2
    print("\n== D. 'Rigid strong coupling' family (one loop) ==")
    print(f"    ln Z (average over spectra) = {math.log(area.mean()/V):.2f}; best single spectrum: ln Z = {math.log(area.max()/V):.2f}")
