#!/usr/bin/env python3
"""
06 - Where can k_Y = 4/3 come from?  Four tests.

 A. Generalised Schellekens condition (heterotic strings, levels k_2 = k_3 = 1):
    electric charges quantised in units of 1/p are possible iff
        [p mod 3 != 0]/3 + [p mod 2 != 0]/4 + p^2 k_Y/4   is an integer.
    (Dienes, Faraggi, March-Russell, hep-th/9510223, eqs 6.30-6.31; p = 1 gives back
     k_3/3 + k_2/4 + k_Y/4 = 0 mod 1, i.e. k_Y >= 5/3.)
 B. Embeddings of U(1)_Y in SU(N): k_Y = 2 tr(Y^2) on the fundamental
    N = (3,1)_a + (1,2)_b + singlets s_j, traceless. Rigid or not?
 C. Weakly coupled heterotic string: M_string = 5.27e17 * g_string GeV (Kaplunovsky),
    a single continuous parameter. Two-loop predictions.
 D. Brane relations (type II) at the string scale:
      (A) 1/alpha_Y = (2/3)/alpha_3 + 1/alpha_2      (Blumenhagen-Lust-Stieberger 2003)
      (B) 1/alpha_Y = (2/3)/alpha_3 + (1/2)/alpha_2  (Pati-Salam-like variant)
    At which scale does the Standard Model satisfy them?
"""
import numpy as np, math, itertools
from fractions import Fraction as Fr
from math import gcd

# ---------- RGE core (identical to script 05) ----------
MT = 173.34; ALPHA0_INV = 137.035999177
b  = np.array([41/10, -19/6, -7.0])
B  = np.array([[199/50, 27/10, 44/5], [9/10, 35/6, 12.0], [11/10, 9/2, -26.0]])
Ct = np.array([17/10, 3/2, 2.0]); K = 1/(16*math.pi**2)
def beta(y):
    g, yt = y[:3], y[3]
    dg = K*b*g**3 + K*K*g**3*(B@(g**2) - Ct*yt**2)
    return np.append(dg, K*yt*(4.5*yt**2 - 17/20*g[0]**2 - 9/4*g[1]**2 - 8*g[2]**2))
def run(y0, t0, t1, n=3000):
    y, h = np.array(y0, float), (t1-t0)/n
    for _ in range(n):
        k1 = beta(y); k2 = beta(y+h/2*k1); k3 = beta(y+h/2*k2); k4 = beta(y+h*k3)
        y = y + h/6*(k1+2*k2+2*k3+k4)
    return y
ainv = lambda g: 4*math.pi/g**2
g3 = 1.1666 + 0.00314*(0.1180-0.1184)/0.0007
Y0 = np.array([math.sqrt(5/3)*0.35830, 0.64779, g3, 0.93690])       # couplings at M_t
obs = np.array([(5/3)*ainv(Y0[0]), ainv(Y0[1]), ainv(Y0[2])])       # 1/alpha_Y, 1/alpha_2, 1/alpha_3

# ---------- A. generalised Schellekens condition ----------
def ok(p, k): return ((Fr(1,3) if p % 3 else 0) + (Fr(1,4) if p % 2 else 0) + Fr(p*p)*k/4).denominator == 1
def pmin(k, pmax=200):
    return next((p for p in range(1, pmax+1) if ok(p, k)), None)
print("== A. Minimal charge unit 1/p required by k_Y (heterotic, level 1) ==")
for k in (Fr(5,3), Fr(4,3), Fr(13,10), Fr(32,25), Fr(5,4), Fr(7,6), Fr(1)):
    print(f"   k_Y = {str(k):6s}  ->  p_min = {pmin(k)}")
lo, hi = Fr(131,100), Fr(137,100)
print(f"   k_Y allowed in the window [{float(lo)}, {float(hi)}] (required k at 2 loops: 1.341 +- 0.004 + thresholds):")
for P in (6, 12):
    found = sorted({Fr(n, d) for p in range(1, P+1) for d in (1,2,3,4,5,6,9,12,16,18,25,36,48,75,100,144)
                    for n in range(d, 2*d+1) if lo <= Fr(n, d) <= hi and pmin(Fr(n, d), P) is not None})
    print(f"     p <= {P:2d} : " + ", ".join(f"{str(k)} (p={pmin(k)})" for k in found))

# ---------- B. embeddings in SU(N) ----------
print("\n== B. k_Y = 2 tr(Y^2) for U(1)_Y in SU(N) ==")
print("   SU(5) : Y = diag(-1/3,-1/3,-1/3,1/2,1/2), unique up to normalisation -> k_Y =", 2*(3*Fr(1,9)+2*Fr(1,4)))
print("   SU(6), with t^c = (3bar,1)_{-2/3} in the adjoint (a - s = 2/3): ONE-parameter family")
print("          k_Y(a) = 24 a^2 - 8 a + 4/3; examples:", {str(a): str(24*a*a-8*a+Fr(4,3)) for a in (Fr(0), Fr(1,6), Fr(1,4), Fr(1,3), Fr(5,12))})
SMADJ = {"Q":("32", Fr(1,6)), "u^c":("31", Fr(2,3)), "d^c":("31", Fr(1,3)), "H/L":("21", Fr(1,2)), "e^c":("11", Fr(1))}
for N in (6, 7):
    ns = N-5; grid = [Fr(i, 12) for i in range(-12, 13)]
    ks = {}
    for a in grid:
        for b_ in grid:
            for s in itertools.combinations_with_replacement(grid, ns-1):
                last = -(3*a + 2*b_ + sum(s)); ss = tuple(s) + (last,)
                if abs(last) > 1: continue
                diffs = {"32": {abs(a-b_)}, "31": {abs(a-x) for x in ss}, "21": {abs(b_-x) for x in ss},
                         "11": {abs(x-y) for x in ss for y in ss}}
                if not any(v in diffs[t] for t, v in SMADJ.values()): continue   # at least one SM field in the adjoint
                k = 2*(3*a*a + 2*b_*b_ + sum(x*x for x in ss))
                if k > 0: ks.setdefault(k, (a, b_, ss))
    win = sorted(k for k in ks if lo <= k <= hi)
    print(f"   SU({N}), charges multiples of 1/12: {len(ks)} distinct values of k_Y, of which {len(win)} in the window:",
          ", ".join(str(k) for k in win[:12]), "..." if len(win) > 12 else "")
print("   Barger et al.: SU(6) diag(1/3,1/3,1/3,-1/3,-1/3,-1/3) -> 4/3; exotic doublet with charges 1/6 and -5/6 (p = 6, cf. A)")

# ---------- C. weakly coupled heterotic string ----------
print("\n== C. Heterotic string: k_Y g_Y^2 = g_2^2 = g_3^2 = g_s^2 at M_s = 5.27e17 g_s GeV (2 loops) ==")
ytop = run(Y0, math.log(MT), math.log(3e17))[3]
def down(gs, kY):
    Ms = 5.27e17*gs
    return run([math.sqrt(5/3)*gs/math.sqrt(kY), gs, gs, ytop], math.log(Ms), math.log(MT))
for kY in (Fr(5,3), Fr(4,3)):
    lo_g, hi_g = 0.45, 0.60
    for _ in range(50):                                    # g_s fitted to alpha_3(M_t)
        mid = (lo_g+hi_g)/2
        if ainv(down(mid, float(kY))[2]) > obs[2]: lo_g = mid
        else: hi_g = mid
    y = down(mid, float(kY)); pred = np.array([(5/3)*ainv(y[0]), ainv(y[1])])
    a0 = ALPHA0_INV + (pred - obs[:2]).sum()
    print(f"   k_Y = {str(kY):4s} : g_s = {mid:.3f}, M_s = {5.27e17*mid:.2e} GeV | 1/a_2 = {pred[1]:.2f} (obs {obs[1]:.2f}), "
          f"1/a_Y = {pred[0]:.2f} (obs {obs[0]:.2f}) | 1/alpha(0) = {a0:.1f} ({100*(a0/ALPHA0_INV-1):+.1f} %)")

# ---------- D. brane relations ----------
print("\n== D. Brane relations: scale at which the SM satisfies them (2 loops) ==")
ts = np.linspace(math.log(MT), math.log(1.3e19), 400); ys = [Y0]
for t0, t1 in zip(ts[:-1], ts[1:]): ys.append(run(ys[-1], t0, t1, n=10))
ys = np.array(ys); aY, a2, a3 = (5/3)*ainv(ys[:,0]), ainv(ys[:,1]), ainv(ys[:,2])
REF = {"M_U (a2=a3)":2.9e16, "heterotic M_s":2.7e17, "reduced M_Planck":2.435e18, "M_Planck":1.22e19}
for name, f in {"(A) 2/3, 1": aY - (2/3)*a3 - a2, "(B) 2/3, 1/2": aY - (2/3)*a3 - 0.5*a2}.items():
    i = np.where(np.sign(f[:-1]) != np.sign(f[1:]))[0]
    Ms = math.exp(np.interp(0, [f[i[0]+1], f[i[0]]], [ts[i[0]+1], ts[i[0]]])) if len(i) else float('nan')
    print(f"   relation {name:13s} satisfied at M_s = {Ms:.2e} GeV")
    for rn, M in REF.items():
        d = np.interp(math.log(M), ts, f)                   # predicted 1/alpha(0) if M_s were imposed
        print(f"        if M_s = {rn:17s}: 1/alpha(0) = {ALPHA0_INV - d:7.2f}  ({-100*d/ALPHA0_INV:+.1f} %)")
