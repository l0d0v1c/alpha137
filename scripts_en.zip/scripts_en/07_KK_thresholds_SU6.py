#!/usr/bin/env python3
"""
07 - Kaluza-Klein thresholds of the 7D SU(6) model (Barger, Jiang, Langacker, Li,
     hep-ph/0504093, section III.B) on M^4 x T^2/Z_6 x S^1/Z_2, and an estimate of the
     relic abundance of fractionally charged states.

4D content of the 7D vector multiplet: V + Sigma_1 + Sigma_2 + Sigma_3, all in the adjoint 35.
Blocks of the adjoint (1 = colour, 2 = doublet, 3 = singlet), Z_6 phases and Z_2 parities
read off eqs (32)-(35) of the paper with n_1 = 2, n_2 = 5.

Mode-counting rules:
  * on T^2/Z_6, each orbit of 6 non-zero momenta provides ONE mode for EACH Z_6 charge;
    the zero-momentum mode exists only for trivial Z_6 charge;
  * on S^1/Z_2, parity +: n >= 0; parity -: n >= 1.
Beta coefficients (convention Q = T_3 + Y, N=1 multiplets): vector -3 T, chiral +T.
"""
import numpy as np, math
from fractions import Fraction as Fr

w = lambda k: k % 6
n1, n2 = 2, 5
ph = {(1,1):0, (2,2):0, (3,3):0, (1,2):-n1, (2,1):n1, (1,3):-n2, (3,1):n2, (2,3):n1-n2, (3,2):n2-n1}
typeA = {(1,1),(2,2),(3,3),(1,2),(2,1)}               # Z_2 parity of V: +; other blocks: -
fields = {"V":(0,+1), "S1":(-1,+1), "S2":(0,-1), "S3":(+1,-1)}   # (phase shift, sign relative to V)
# (tr Y^2, T_SU2, T_SU3) of each block, Y = diag(1/3,1/3,1/3,-1/3,-1/3,-1/3)
idx = {(1,1):(Fr(0),Fr(0),Fr(3)), (2,2):(Fr(0),Fr(2),Fr(0)), (3,3):(Fr(0),)*3,
       (1,2):(Fr(8,3),Fr(3,2),Fr(1)), (2,1):(Fr(8,3),Fr(3,2),Fr(1)),
       (1,3):(Fr(4,3),Fr(0),Fr(1,2)), (3,1):(Fr(4,3),Fr(0),Fr(1,2)),
       (2,3):(Fr(0),Fr(1,2),Fr(0)), (3,2):(Fr(0),Fr(1,2),Fr(0))}
def content(select):
    b = [Fr(0)]*3; lst = []
    for f, (dk, sg) in fields.items():
        for blk, k in ph.items():
            par = (+1 if blk in typeA else -1)*sg
            if select(w(k+dk), par):
                c = -3 if f == "V" else 1
                b = [x + c*y for x, y in zip(b, idx[blk])]; lst.append(f"{f}{blk}")
    return b, lst
b0, l0 = content(lambda k, par: k == 0 and par == +1)       # zero modes
bI, lI = content(lambda k, par: k == 0)                     # tower p = 0, n >= 1
bII, lII = content(lambda k, par: par == +1)                # towers p != 0, n = 0
bIII, _ = content(lambda k, par: True)                      # p != 0, n >= 1: complete N=4 multiplet
print("zero modes              :", l0)
print("tower (i)   p=0,  n>=1  : (b_Y, b_2, b_3) =", [str(x) for x in bI])
print("tower (ii)  p!=0, n=0   : (b_Y, b_2, b_3) =", [str(x) for x in bII], " -> non-universal: b_Y/k_Y =", bII[0]*Fr(3,4))
print("tower (iii) p!=0, n>=1  : (b_Y, b_2, b_3) =", [str(x) for x in bIII], " (N=4)")

# ---- shift of the apparent k_Y ----
bSM = np.array([41/6, -19/6, -7.0]); aU = 46.18; kY = 4/3
def S1(LRp): return sum(math.log(LRp/n) for n in range(1, int(LRp)+1) if n < LRp)
def S2(LR):
    s, m = 0.0, int(LR)+2
    for a in range(-m, m+1):
        for c in range(-m, m+1):
            N = a*a - a*c + c*c
            if N and (2/math.sqrt(3))*math.sqrt(N) < LR: s += math.log(LR/((2/math.sqrt(3))*math.sqrt(N)))/6
    return s
def dk(LR, LRp):
    s1, s2 = S1(LRp), S2(LR)
    D = (np.array([float(x) for x in bI])*s1 + np.array([float(x) for x in bII])*s2)/(2*math.pi)
    lnMU = (D[1]-D[2])/((bSM[1]-bSM[2])/(2*math.pi))             # ln(apparent M_U / Lambda)
    aY = kY*aU + D[0] - bSM[0]*lnMU/(2*math.pi); a2 = aU + D[1] - bSM[1]*lnMU/(2*math.pi)
    return aY/a2 - kY, lnMU
print("\napparent k_Y - 4/3 (required by the two-loop analysis: +0.0077 +- 0.0038)")
grid = (1.0, 1.2, 1.5, 2.0, 3.0, 5.0)
print("  Lambda*R' \\ Lambda*R : " + "  ".join(f"{x:6.1f}" for x in grid))
for LRp in grid:
    print(f"        {LRp:4.1f}          : " + "  ".join(f"{dk(LR, LRp)[0]:+6.3f}" for LR in grid))
ok = [(LR, LRp) for LR in np.arange(1.0, 6.01, 0.05) for LRp in np.arange(1.0, 6.01, 0.05)
      if 0.0001 <= dk(LR, LRp)[0] <= 0.0153]
print(f"  region compatible at 2 sigma: Lambda*R <= {max(x for x,_ in ok):.2f}, Lambda*R' <= {max(y for _,y in ok):.2f}")
# 7D strong-coupling bound (naive dimensional analysis)
l7 = (4*math.pi)**3.5*math.gamma(3.5); vol = (math.sqrt(3)/2)*(2*math.pi)**2/6*math.pi
print(f"  7D strong coupling (NDA): Lambda*R ~ {(l7*aU/(4*math.pi)/vol)**(1/3):.0f}  (for R = R')")

# ---- fractionally charged relics ----
print("\nStable fractionally charged relics (mass M ~ 1/R ~ 2e16 GeV), thermal production")
MPl, gs, M, al, Nch, g = 1.22e19, 106.75, 2e16, 1/46.2, 10, 12
def omega(x):                                                   # x = M / T_max
    T = M/x; neq2 = g*g*(M*T/(2*math.pi))**3*math.exp(-2*x)
    Y = (math.pi*al*al*Nch/M**2)*neq2/(2*x) / ((2*math.pi**2/45)*gs*T**3 * 1.66*math.sqrt(gs)*T**2/MPl)
    return M*Y/3.6e-9
for target, lab in ((0.12, "all of the dark matter"), (1.2e-11, "1e-10 of the dark matter")):
    lo, hi = 1.0, 200.0
    for _ in range(60):
        mid = (lo+hi)/2
        if omega(mid) > target: lo = mid
        else: hi = mid
    print(f"  Omega h^2 < {target:.1e} ({lab}): T_max < M/{mid:.0f} = {M/mid:.1e} GeV")
