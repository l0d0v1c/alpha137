#!/usr/bin/env python3
"""
04 - 'Common strong coupling' scenario: MSSM + n complete SU(5) multiplets (n = n5 + 3 n10)
     at the scale M (superpartners included), alpha_i^-1(Lambda) = c * k_i with c in [0,1].
     Lambda is fitted to alpha_s; alpha_2, alpha_Y, sin^2(theta_W) and 1/alpha(0) are predicted.
     Shows the hypersensitivity to M: d(1/alpha(0))/d ln M ~ 11.   One loop.
"""
import math
tp = 2*math.pi; MZ = 91.1876
A = dict(Y=98.366, w=29.585, s=8.4746)                 # 1/alpha_i(M_Z)
D_IR = 137.035999 - 127.951                            # running from M_Z down to 0
bSM = dict(Y=41/6, w=-19/6, s=-7.0); bMSSM = dict(Y=11.0, w=1.0, s=-3.0)
k = dict(Y=5/3, w=1.0, s=1.0)                          # one complete multiplet: db_i = k_i

print(" n   M(TeV)   c    Lambda(GeV)   1/a_2    1/a_Y    sin2_W   1/alpha(0)")
for n in (5, 6, 7):
    for M in (1e3, 3e3, 1e4, 3e4):
        for c in (0, 0.5, 1):
            t = math.log(M/MZ)
            Bh = {i: bMSSM[i] + n*k[i] for i in A}
            xt = (tp*(A['s'] - c) - bSM['s']*t)/Bh['s']          # ln(Lambda/M) fitted to alpha_s
            p = {i: c*k[i] + (bSM[i]*t + Bh[i]*xt)/tp for i in A}
            am = p['Y'] + p['w']
            print(f" {n}   {M/1e3:5.0f}   {c:3.1f}   {M*math.exp(xt):10.2e}   {p['w']:6.2f}   {p['Y']:6.2f}   {p['w']/am:.4f}   {am + D_IR:8.2f}")
