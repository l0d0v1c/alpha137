#!/usr/bin/env python3
"""
05 - Hypercharge normalisation k_Y and prediction of 1/alpha(0),
     Standard Model only, at one and two loops.

Principle: impose alpha_Y^-1 / k_Y = alpha_2^-1 = alpha_3^-1 = alpha_U^-1 at M_U.
(M_U, alpha_U) are fitted to the measured alpha_2 and alpha_3; alpha_Y is then PREDICTED,
hence 1/alpha(0) as well:  1/alpha(0)_pred = 137.036 + [alpha_Y^-1 pred - alpha_Y^-1 obs](M_t).

Inputs: MS-bar couplings at mu = M_t = 173.34 GeV, extracted at NNLO by
Buttazzo et al., JHEP 12 (2013) 089 [arXiv:1307.3536], eqs (57)-(59):
  g_Y = 0.35830, g_2 = 0.64779, y_t = 0.93690,
  g_3 = 1.1666 + 0.00314*(alpha_s(MZ)-0.1184)/0.0007
Equations: two-loop SM gauge RGEs (Machacek-Vaughn), one-loop top Yukawa.
Internal normalisation: g1^2 = (5/3) g_Y^2 (a computational convention, with no effect on k_Y).
"""
import numpy as np, math
from fractions import Fraction as Fr

MT = 173.34
ALPHA0_INV = 137.035999177
b  = np.array([41/10, -19/6, -7.0])
B  = np.array([[199/50, 27/10, 44/5],
               [9/10,   35/6,  12.0],
               [11/10,  9/2,  -26.0]])
Ct = np.array([17/10, 3/2, 2.0])
K  = 1/(16*math.pi**2)

def beta(y, loops):
    g, yt = y[:3], y[3]
    dg = K*b*g**3
    if loops == 2:
        dg = dg + K*K*g**3*(B@(g**2) - Ct*yt**2)
    dyt = K*yt*(4.5*yt**2 - 17/20*g[0]**2 - 9/4*g[1]**2 - 8*g[2]**2)
    return np.append(dg, dyt)

def run(y0, t0, t1, loops, n=4000):
    """Runge-Kutta 4 from t0 to t1, t = ln(mu/GeV)."""
    y, h = np.array(y0, float), (t1-t0)/n
    for _ in range(n):
        k1 = beta(y, loops); k2 = beta(y+h/2*k1, loops)
        k3 = beta(y+h/2*k2, loops); k4 = beta(y+h*k3, loops)
        y = y + h/6*(k1+2*k2+2*k3+k4)
    return y

ainv = lambda g: 4*math.pi/g**2

def inputs(alpha_s=0.1180, dyt=0.0):
    gY, g2, yt = 0.35830, 0.64779, 0.93690+dyt
    g3 = 1.1666 + 0.00314*(alpha_s-0.1184)/0.0007
    return np.array([math.sqrt(5/3)*gY, g2, g3, yt])

def k_requis(y0, loops):
    """Run the couplings up, find M_U where alpha_2 = alpha_3, return (M_U, alpha_U^-1, required k_Y)."""
    t, y, h = math.log(MT), y0.copy(), 0.05
    while True:
        yn = run(y, t, t+h, loops, n=20)
        if ainv(yn[1]) - ainv(yn[2]) < 0:   # crossing inside [t, t+h]: bisection
            lo, hi = 0.0, h
            for _ in range(40):
                mid = (lo+hi)/2; ym = run(y, t, t+mid, loops, n=20)
                if ainv(ym[1]) - ainv(ym[2]) < 0: hi = mid
                else: lo = mid
            ym = run(y, t, t+lo, loops, n=20)
            aU = ainv(ym[1]); aYinv = (5/3)*ainv(ym[0])
            return math.exp(t+lo), aU, aYinv/aU, ym[3]
        t, y = t+h, yn

def prediction(kY, y0, loops):
    """Fit (M_U, alpha_U) to alpha_2, alpha_3 at M_t by Newton iteration; predict alpha_Y^-1(M_t)."""
    MU, aU, _, ytU = k_requis(y0, loops)
    p = np.array([math.log(MU), aU])
    target = np.array([ainv(y0[1]), ainv(y0[2])])
    def down(p):
        gU = math.sqrt(4*math.pi/p[1])
        gYU = math.sqrt(4*math.pi/(kY*p[1]))
        y = run([math.sqrt(5/3)*gYU, gU, gU, ytU], p[0], math.log(MT), loops, n=3000)
        return y
    for _ in range(12):
        y = down(p); r = np.array([ainv(y[1]), ainv(y[2])]) - target
        if np.abs(r).max() < 1e-10: break
        J = np.zeros((2,2))
        for j, e in enumerate((1e-4, 1e-4)):
            dp = p.copy(); dp[j] += e; yy = down(dp)
            J[:,j] = (np.array([ainv(yy[1]), ainv(yy[2])]) - target - r)/e
        p = p - np.linalg.solve(J, r)
    y = down(p)
    aY_pred = (5/3)*ainv(y[0]); aY_obs = (5/3)*ainv(y0[0])
    return math.exp(p[0]), p[1], ALPHA0_INV + aY_pred - aY_obs

if __name__ == "__main__":
    y0 = inputs()
    print("Inputs at M_t: 1/alpha_Y = %.3f  1/alpha_2 = %.3f  1/alpha_3 = %.3f"
          % ((5/3)*ainv(y0[0]), ainv(y0[1]), ainv(y0[2])))
    print("\n== k_Y required for exact unification ==")
    for loops in (1, 2):
        MU, aU, k, _ = k_requis(y0, loops)
        print(f"{loops} loop(s): M_U = {MU:.3e} GeV   1/alpha_U = {aU:.3f}   k_Y = {k:.4f}")
    print("\n== uncertainties on k_Y at two loops ==")
    k0 = k_requis(y0, 2)[2]
    for lab, yy in [("alpha_s +0.0009", inputs(0.1189)), ("alpha_s -0.0009", inputs(0.1171)),
                    ("y_t +0.005 (~ M_t +1 GeV)", inputs(dyt=0.005))]:
        print(f"  {lab:28s} dk_Y = {k_requis(yy,2)[2]-k0:+.4f}")
    print("\n== prediction of 1/alpha(0) as a function of k_Y ==")
    print(" k_Y        1 loop     2 loops     dev. 2l    M_U (2l)")
    for fr in (Fr(5,3), Fr(4,3), Fr(13,10), Fr(32,25), Fr(5,4), Fr(6,5), Fr(1,1)):
        r1 = prediction(float(fr), y0, 1); r2 = prediction(float(fr), y0, 2)
        print(f" {str(fr):6s}   {r1[2]:9.2f}   {r2[2]:9.2f}   {100*(r2[2]/ALPHA0_INV-1):+6.2f} %   {r2[0]:.2e}")
