#!/usr/bin/env python3
"""
02 - Search for coincidences between physical constants and products of volumes
     of symmetric spaces (Cartan domains I-IV, spheres, Shilov boundaries),
     with a look-elsewhere control based on decoy targets.
"""
import numpy as np, itertools
from math import pi, factorial as f, gamma, log

def prod(it):
    r = 1.0
    for x in it: r *= x
    return r

B = {}
for n in range(1, 9):                                            # type IV (Lie balls)
    B[f"IV{n}"] = pi**n/(2**(n-1)*f(n))
for m, n in [(1,2),(1,3),(1,4),(1,5),(2,2),(2,3),(2,4),(3,3)]:   # type I (m,n)
    B[f"I{m}{n}"] = prod(f(k) for k in range(1,m))*prod(f(k) for k in range(1,n)) \
                    / prod(f(k) for k in range(1,m+n)) * pi**(m*n)
for n in (2, 3):                                                 # type II
    B[f"II{n}"] = pi**(n*(n+1)/2)/2**(n*(n-1)/2) \
                  * prod(f(2*k) for k in range(1,n))/prod(f(k) for k in range(n,2*n))
for n in (3, 4, 5):                                              # type III
    B[f"III{n}"] = pi**(n*(n-1)/2) \
                   * prod(f(2*k) for k in range(1,n-1))/prod(f(k) for k in range(n-1,2*n-2))
for k in range(1, 9): B[f"S{k}"] = 2*pi**((k+1)/2)/gamma((k+1)/2)
for n in range(2, 9): B[f"Q{n}"] = 2*pi**(n/2+1)/gamma(n/2)

names = list(B); L = np.array([log(B[k]) for k in names]); nb = len(names)
EXP = np.array([-2, -1, -.5, -.25, .25, .5, 1, 2])
C = {"1":1, "2":2, "3":3, "4":4, "1/2":.5, "1/3":1/3, "1/4":.25, "3/2":1.5, "2/3":2/3}
cn = list(C); lc = np.array([log(v) for v in C.values()])
TARGETS = {"1/alpha":137.035999177, "mp/me":1836.152673426,
           "mmu/me":206.7682827, "mn/me":1838.68366200}       # CODATA 2022
lt = {k: log(v) for k, v in TARGETS.items()}

vals, hits = [], {k: [] for k in TARGETS}
for r in (1, 2, 3):
    for comb in itertools.combinations(range(nb), r):
        v = lc.copy()
        for i in comb: v = v[..., None] + L[i]*EXP
        for k in TARGETS:
            for ix in np.argwhere(np.abs(v-lt[k]) < 1e-6):
                hits[k].append((float(abs(v[tuple(ix)]-lt[k])), comb, tuple(ix)))
        vals.append(v.ravel())
V = np.unique(np.round(np.concatenate(vals), 11))
print(nb, "building blocks;", len(V), "distinct values")

rng = np.random.default_rng(1)
for k in TARGETS:
    print("\n==", k)
    for tol in (1e-5, 1e-6, 1e-7, 1e-8):
        n = np.searchsorted(V, lt[k]+tol) - np.searchsorted(V, lt[k]-tol)
        d = lt[k] + rng.uniform(-.2, .2, 4000)                   # local decoy targets
        nd = np.searchsorted(V, d+tol) - np.searchsorted(V, d-tol)
        print(f"  tol {tol:.0e}: real {n:3d} | decoys, mean {nd.mean():6.2f} | P(decoy >= real) = {np.mean(nd>=n):.2f}")
    for e, comb, ix in sorted(hits[k])[:4]:
        s = cn[ix[0]] + " * " + " * ".join(f"{names[i]}^{EXP[j]:g}" for i, j in zip(comb, ix[1:]))
        print(f"     deviation {e:.1e}:  {s}")
