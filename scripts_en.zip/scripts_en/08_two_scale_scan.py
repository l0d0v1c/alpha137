#!/usr/bin/env python3
"""
08 - Extension of scan 03 to TWO mass scales: M_c for coloured multiplets (D, U, Q, G),
     M_u for uncoloured ones (E, L, T). Standard Model base, one loop.
     Same condition: 0 <= alpha_i^-1(Lambda) <= 1 for i = Y, 2, 3, with M_c, M_u >= 1 TeV.
     Question: does the mild preference for our world in the Planck window (script 03) survive
     the addition of one continuous parameter?

Usage: python3 08_two_scale_scan.py [number_of_decoys]   (default 20; ~15 s per evaluation)
"""
import numpy as np, itertools, math, sys, time
tp = 2*math.pi; MZ = 91.1876
A = np.array([127.951*(1-0.23122), 127.951*0.23122, 1/0.1180])
bSM = np.array([41/6, -19/6, -7.0])
FIELDS = {"E":(4/3,0,0), "L":(2/3,2/3,0), "D":(4/9,0,2/3), "U":(16/9,0,2/3), "Q":(2/9,2,4/3), "T":(0,4/3,0), "G":(0,0,2)}
names = list(FIELDS); C = np.array(list(FIELDS.values()), dtype=np.float32)
S = np.array(list(itertools.product(*[range(7)]*5, range(3), range(3))), dtype=np.float32)
col = np.array([n in "DUQG" for n in names])
DC = S[:, col] @ C[col]; DU = S[:, ~col] @ C[~col]            # coloured / uncoloured contributions

def feasible2(A, xlo, xhi, nx, ny=60, chunk=6000, Mmin=1000.):
    x = np.linspace(xlo, xhi, nx, dtype=np.float32); ymax = x - np.float32(math.log(Mmin/MZ))
    y2 = np.linspace(0, 1, ny, dtype=np.float32)[None, :]*ymax[:, None]          # (nx, ny)
    out = np.zeros(len(S), bool)
    for s in range(0, len(S), chunk):
        dc, du = DC[s:s+chunk], DU[s:s+chunk]
        lo = np.zeros((len(dc), nx, ny), np.float32); hi = np.broadcast_to(ymax[None, :, None], lo.shape).copy()
        ok = np.ones(lo.shape, bool)
        for i in range(3):
            up = (tp*A[i] - bSM[i]*x).astype(np.float32)[None, :, None] - du[:, i][:, None, None]*y2[None]
            dn = up - np.float32(tp); d = dc[:, i][:, None, None]
            pos = d > 0
            with np.errstate(divide='ignore', invalid='ignore'):
                lo = np.maximum(lo, np.where(pos, dn/d, -np.inf)); hi = np.minimum(hi, np.where(pos, up/d, np.inf))
            ok &= pos | ((dn <= 0) & (up >= 0))
        out[s:s+chunk] = (ok & (lo <= hi)).any(axis=(1, 2))
    return out

if __name__ == "__main__":
    ndec = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    X = lambda lam: math.log(lam/MZ); rng = np.random.default_rng(5)
    t0 = time.time()
    free = feasible2(A, X(1e10), X(1.22e19), 50)
    print(f"Lambda free       : {free.sum()} compatible spectra ({100*free.mean():.2f} %)   [one scale: 2565]", flush=True)
    a, b = X(2.435e18), X(1.22e19)
    pl = feasible2(A, a, b, 16)
    print(f"Planck window     : {pl.sum()} compatible spectra ({100*pl.mean():.2f} %)   [one scale: 645]", flush=True)
    comp = S.sum(1); print("minimal complexity:", int(comp[pl].min()), "| time per evaluation ~", round((time.time()-t0)/2), "s", flush=True)
    for w in (1.25, 1.5):
        dec = A*np.exp(rng.uniform(-math.log(w), math.log(w), (ndec, 3)))
        nd = np.array([feasible2(d, a, b, 16).sum() for d in dec])
        print(f"decoys x{w} ({ndec}): median {np.median(nd):.0f}, q90 {np.quantile(nd, .9):.0f}, P(decoy >= real) = {np.mean(nd >= pl.sum()):.2f}", flush=True)
