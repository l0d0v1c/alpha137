#!/usr/bin/env python3
"""
01 - Wyler's formula: generalisation to dimension n, and brute-force search
     in the class 2^a 3^b 5^c pi^d (quarter-integer exponents).
"""
import numpy as np, math
from math import pi, gamma, factorial

T = 137.035999177                      # 1/alpha, CODATA 2022

def VD(n): return pi**n/(2**(n-1)*factorial(n))          # Cartan domain of type IV (Hua)
def VQ(n): return 2*pi**(n/2+1)/gamma(n/2)               # Shilov boundary Q^n
def VS(k): return 2*pi**((k+1)/2)/gamma((k+1)/2)         # sphere S^k

print("== Wyler in dimension n:  alpha = 3 V(S^{n-1}) / V(Q^n)^2 * V(D^n)^(1/4) ==")
for n in range(3, 9):
    a = VS(n-1)/VQ(n)*(3/VQ(n))*VD(n)**0.25
    print(f"  n = {n}   1/alpha = {1/a:.5f}")
print("  closed form n=5:", 2**4.75*3**-1.75*5**.25*pi**2.75)

print("\n== Brute-force search 2^a 3^b 5^c pi^d, exponents multiples of 1/4 ==")
L = [math.log(x) for x in (2, 3, 5, pi)]; lt = math.log(T)
for R in (8, 16, 24):                                    # exponents in [-R/4, R/4]
    e = np.arange(-R, R+1)/4
    s01 = (e[:,None]*L[0] + e[None,:]*L[1]).ravel()
    s23 = np.sort((e[:,None]*L[2] + e[None,:]*L[3]).ravel())
    for tol in (1e-6, 1e-7, 1e-8):
        n = (np.searchsorted(s23, lt-s01+tol) - np.searchsorted(s23, lt-s01-tol)).sum()
        print(f"  |exponent| <= {R/4:.0f}   tolerance {tol:.0e} : {int(n)} formula(e)")
